# WashFlow — Logo Files

## Brand
- Product:  WashFlow — Multi-Tenant CarWash CRM
- Platform: flux-lab.dev
- Primary:  #0EA5E9 (cyan/sky)
- BG dark:  #040D12 / #050E14

## Icons (17 files)
| File | Use |
|------|-----|
| icon_dark_rounded_512 | App Store, high-res |
| icon_dark_rounded_256 | Marketing, OG image |
| icon_dark_rounded_128 | General purpose |
| icon_dark_rounded_96  | Site navbar |
| icon_dark_rounded_64  | UI components |
| icon_dark_rounded_32  | Favicon, browser tab |
| icon_dark_circle_512  | Social media avatar |
| icon_dark_circle_256  | Social media |
| icon_dark_circle_96   | Small avatar |
| icon_cyan_rounded_512 | Marketing, CTA contexts |
| icon_cyan_rounded_96  | Colored UI |
| icon_cyan_circle_512  | Social — colored |
| icon_cyan_circle_96   | Colored avatar |
| icon_light_rounded_512 | Light theme export |
| icon_light_rounded_96  | Light theme navbar |
| icon_outline_rounded_512 | Monochrome print |
| icon_outline_rounded_96  | Monochrome UI |

## Lockups (3 files)
| File | Use |
|------|-----|
| lockup_dark.svg    | Dark site header |
| lockup_light.svg   | Light site header |
| lockup_powered.svg | With "Powered by flux-lab.dev" badge |
